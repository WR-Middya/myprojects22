
public class PrintingPettern {
	public static void main(String[] args) {
		
		int m,n;
		n = 19;
		m=5;
		
		//Printing numbers:
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
		
		System.out.println();
		//Printing pattern:
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						if (i==0||j==0||i==n-1||j==n-1|| i+j<=n/2||j-i>=n/2) {
							System.out.print("*\s");
						}
						else {
							System.out.print(" \s");
						}
					}
					System.out.println();
				}
				
				
				//Printing pattern:
						for (int i = 0; i < n; i++) {
							for (int j = 0; j < n; j++) {
								if (i-j>=n/2||i+j>=(n-1)+n/2) {
									System.out.print("*\s");
								}
								else {
									System.out.print(" \s");
								}
							}
							System.out.println();
						}
						
						System.out.println();
						System.out.println();
						//Printing pattern:
								for (int i = 0; i < n; i++) {
									for (int j = 0; j < n; j++) {
										if (i-j>=n/2||i+j<=n/2||i==0||i==n-1||j==0) {
											System.out.print("*\s");
										}
										else {
											System.out.print(" \s");
										}
									}
									System.out.println();
								}
		
	}
}
