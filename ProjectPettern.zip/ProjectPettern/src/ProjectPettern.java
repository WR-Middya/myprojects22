
public class ProjectPettern {
	public static void main(String args[]) {
		
		/*		Declaration of variables		*/
		int n;
		n = 7;
		
		
		/*-------------------- WASIM RAJA MIDDYA ---------------------*/
		System.out.println();
		for(int i=0;i<n;i++) {
			System.out.print("\t");
			/*		Logic for printing W letter		*/
			for(int j=0;j<n;j++) {
				if(i==n-1&&j!=n/2&&j!=0&&j!=n-1||j==0&&i!=n-1||j==n-1&&i!=n-1||i<n&&i>(n-2)/2&&j==n/2&&i!=n-1) {
			
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing A letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i!=0||j==n-1&&i!=0||i==n/2||i==0&&j!=0&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing S letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=0||i==n/2&&j!=0&&j!=n-1||i==n-1&&j!=n-1||i>0&&i<n/2&&j==0||i>n/2&&i<n-1&&j==n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print(" \s");
			
			/*		Logic for printing I letter		*/
			for(int j=0;j<n;j++) {
				if(i==0||j==n/2||i==n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing M letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=n/2&&j!=0&&j!=n-1||j==0&&i!=0||j==n-1&&i!=0||i>0&&i<(n+1)/2&&j==n/2) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			
			System.out.print("  \t");
			/*		Logic for printing R letter		*/
			for(int j=0;j<n;j++) {
				if(j==0||j==n-1&&i!=0&&i!=n/2||i==0&&j!=n-1||i==n/2&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing A letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i!=0||j==n-1&&i!=0||i==n/2||i==0&&j!=0&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing J letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=n-1||j==n-1&&i!=0&&i!=n-1||i==n-1&&j!=0&&j!=n-1||j==0&&i>n/2&&i<n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing A letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i!=0||j==n-1&&i!=0||i==n/2||i==0&&j!=0&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.println();
		}
		System.out.println();
		
		
		for(int i=0;i<n;i++) {
			System.out.print("\t\t\t\t");
			/*		Logic for printing M letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=n/2&&j!=0&&j!=n-1||j==0&&i!=0||j==n-1&&i!=0||i>0&&i<(n+1)/2&&j==n/2) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing I letter		*/
			for(int j=0;j<n;j++) {
				if(i==0||j==n/2||i==n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing D letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=n-1||j==n-1&&i!=0&&i!=n-1||i==n-1&&j!=n-1||j==0) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing D letter		*/
			for(int j=0;j<n;j++) {
				if(i==0&&j!=n-1||j==n-1&&i!=0&&i!=n-1||i==n-1&&j!=n-1||j==0) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing Y letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i>=0&&i<n/2||j==n-1&&i>=0&&i<n/2||i==n/2&&j>0&&j<n-1||j==n/2&&i>n/2) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing A letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i!=0||j==n-1&&i!=0||i==n/2||i==0&&j!=0&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.println();
		}
		/* ----------------------- END --------------------------- */
		
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		
		/* ----------------------- INEURON ------------------- */
		for (int i = 0; i<n; i++) {
			System.out.print("\t\t\t");
			/*		Logic for printing I letter		*/
			for(int j=0;j<n;j++) {
				if(i==0||j==n/2||i==n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing N letter		*/
			for(int j=0;j<n;j++) {
				if(j==0||j==n-1||j==i) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing E letter		*/
			for(int j=0;j<n;j++) {
				if(j==0||i==0||i==n/2||i==n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing U letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i>=0&&i<n-1||i==n-1&&j>0&&j<n-1||j==n-1&&i>=0&&i<n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing R letter		*/
			for(int j=0;j<n;j++) {
				if(j==0||j==n-1&&i!=0&&i!=n/2||i==0&&j!=n-1||i==n/2&&j!=n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing O letter		*/
			for(int j=0;j<n;j++) {
				if(j==0&&i>0&&i<n-1||i==n-1&&j>0&&j<n-1||j==n-1&&i>0&&i<n-1||i==0&&j>0&&j<n-1) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.print("\s");
			
			/*		Logic for printing N letter		*/
			for(int j=0;j<n;j++) {
				if(j==0||j==n-1||j==i) {
					System.out.print("*\s");
				}
				else {
					System.out.print(" \s");
				}
			}
			System.out.println();
		}
		
		
	}
}
