import java.util.Scanner;
import java.util.Random;

class Guesser
{
	int guessNum;
	private Scanner scan;
	
	public int guessNumber()
	{
		int n;
		Random rand = new Random();
		scan = new Scanner(System.in);
		
		// Fixed the range of guessing numbers such as 0 to 10......
		System.out.print("Guesser please guess a number from 0 to ");
		n = scan.nextInt();
		guessNum = rand.nextInt(n+1);
		return guessNum;	
	}	
}

class Player
{
	int pguessNum;
	private Scanner scan;
	
	public int guessNumber(int arg)
	{
		scan = new Scanner(System.in);
		System.out.println("Player "+(arg+1)+" kindly guess the number");
		pguessNum=scan.nextInt();
		return pguessNum;
	}
}

class Umpire
{
	int numFromGuesser;
	int numFromPlayer[];
	int numOfPlayers;	//Instance variable for assigning number players or fixed the range of number of players.....
	private Scanner scan;
	
	public void collectNumFromGuesser()
	{
		Guesser g=new Guesser();
		numFromGuesser=g.guessNumber();
		
	}
	
	public void collectNumFromPlayer()
	{
		
		Player p = new Player();
		scan = new Scanner(System.in);
		
		// Taking input from the user to set the number of players....
		System.out.println("Enter the number of players ");
		numOfPlayers = scan.nextInt();
		
		// Fixed the range of number players.....
		numFromPlayer = new int[numOfPlayers];
		
		for (int i = 0; i < numFromPlayer.length; i++) {
			numFromPlayer[i] = p.guessNumber(i);
		}
	}
	
	void compare()
	{
		boolean isTrue = false;
		int sumOfWinner=0;
		int[] indexOf = new int[numOfPlayers];
		
		// Comparison logic....
		for (int i = 0; i < numFromPlayer.length; i++) {
				if(numFromPlayer[i]==numFromGuesser) {
					indexOf[i] = i+1;
					sumOfWinner += 1;
					isTrue = true;
			}
		}
			
		// Winner Declaration logic....
		if(isTrue)
		{
			for (int i = 0; i < indexOf.length; i++) {
				if(sumOfWinner==numOfPlayers) {
					System.out.println("All the players have guessed the currect answare");
					break;
				}
				else if(indexOf[i]!=0) {
					System.out.println("Player "+indexOf[i]+" has guessed currect answare.");
				}
			}
		}
		else {
				System.out.println("Game lost, no one guess the currect answare.");
		}
		System.out.println("The guessed number is "+numFromGuesser);
	}
	
}

public class LaunchGame {
	public static void main(String[] args) {
		
		Umpire u = new Umpire();
		u.collectNumFromGuesser();
		u.collectNumFromPlayer();
		u.compare();

	}
}
